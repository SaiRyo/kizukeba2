-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- ホスト: localhost
-- 生成時間: 2015 年 1 月 04 日 01:52
-- サーバのバージョン: 5.1.44
-- PHP のバージョン: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- データベース: `shop`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `dat_member`
--

CREATE TABLE IF NOT EXISTS `dat_member` (
  `code` int(11) NOT NULL AUTO_INCREMENT COMMENT '会員コード',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '会員登録日時',
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'パスワード',
  `name` varchar(15) COLLATE utf8_unicode_ci NOT NULL COMMENT 'お名前',
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'メールアドレス',
  `postal1` varchar(3) COLLATE utf8_unicode_ci NOT NULL COMMENT '郵便番号１',
  `postal2` varchar(4) COLLATE utf8_unicode_ci NOT NULL COMMENT '郵便番号２',
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '住所',
  `tel` varchar(13) COLLATE utf8_unicode_ci NOT NULL COMMENT '電話番号',
  `danjo` int(11) NOT NULL COMMENT '性別',
  `born` int(11) NOT NULL COMMENT '生まれ年',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='会員情報テーブル' AUTO_INCREMENT=2 ;

--
-- テーブルのデータをダンプしています `dat_member`
--

INSERT INTO `dat_member` (`code`, `date`, `password`, `name`, `email`, `postal1`, `postal2`, `address`, `tel`, `danjo`, `born`) VALUES
(1, '2014-11-10 02:05:40', '93207db25ad357906be2fd0c3f65f3dc', 'うちはサスケ', 'sakuke@gmail.com', '111', '2222', '木の葉の里', '090-222-4444', 2, 1990);

-- --------------------------------------------------------

--
-- テーブルの構造 `dat_sales`
--

CREATE TABLE IF NOT EXISTS `dat_sales` (
  `code` int(11) NOT NULL AUTO_INCREMENT COMMENT '注文コード',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '注文日時',
  `code_member` int(11) NOT NULL COMMENT '会員コード',
  `name` varchar(15) COLLATE utf8_unicode_ci NOT NULL COMMENT 'お名前',
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'メールアドレス',
  `postal1` varchar(3) COLLATE utf8_unicode_ci NOT NULL COMMENT '郵便番号１',
  `postal2` varchar(4) COLLATE utf8_unicode_ci NOT NULL COMMENT '郵便番号２',
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '住所',
  `tel` varchar(13) COLLATE utf8_unicode_ci NOT NULL COMMENT '電話番号',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='注文テーブル' AUTO_INCREMENT=9 ;

--
-- テーブルのデータをダンプしています `dat_sales`
--

INSERT INTO `dat_sales` (`code`, `date`, `code_member`, `name`, `email`, `postal1`, `postal2`, `address`, `tel`) VALUES
(1, '2014-11-08 23:43:18', 0, 'NARUTO', 'test@yahoo.co.jp', '955', '0000', '木の葉の里', '090-222-4444'),
(2, '2014-11-08 23:59:39', 0, 'NARUTO', 'test@yahoo.co.jp', '955', '0000', '木の葉の里', '090-222-4444'),
(3, '2014-11-09 00:04:55', 0, 'NARUTO', 'test@yahoo.co.jp', '955', '0000', '木の葉の里', '090-222-4444'),
(4, '2014-11-09 00:06:16', 0, 'NARUTO', 'test@yahoo.co.jp', '955', '0000', '木の葉の里', '090-222-4444'),
(5, '2014-11-09 01:47:14', 0, 'NARUTO', 'test@yahoo.co.jp', '955', '0000', '木の葉の里', '090-222-4444'),
(6, '2014-11-10 02:05:40', 1, 'うちはサスケ', 'sakuke@gmail.com', '111', '2222', '木の葉の里', '090-222-4444'),
(7, '2014-11-11 19:57:33', 1, 'うちはサスケ', 'sakuke@gmail.com', '111', '2222', '木の葉の里', '090-222-4444'),
(8, '2014-11-11 19:58:51', 1, 'うちはサスケ', 'sakuke@gmail.com', '111', '2222', '木の葉の里', '090-222-4444');

-- --------------------------------------------------------

--
-- テーブルの構造 `dat_sales_product`
--

CREATE TABLE IF NOT EXISTS `dat_sales_product` (
  `code` int(11) NOT NULL AUTO_INCREMENT COMMENT '注文明細コード',
  `code_sales` int(11) NOT NULL COMMENT '注文コード',
  `code_product` int(11) NOT NULL COMMENT '商品コード',
  `price` int(11) NOT NULL COMMENT '価格',
  `quantity` int(11) NOT NULL COMMENT '数量',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='注文明細テーブル' AUTO_INCREMENT=9 ;

--
-- テーブルのデータをダンプしています `dat_sales_product`
--

INSERT INTO `dat_sales_product` (`code`, `code_sales`, `code_product`, `price`, `quantity`) VALUES
(1, 4, 5, 111, 1),
(2, 4, 1, 300, 1),
(3, 5, 5, 111, 1),
(4, 5, 1, 300, 1),
(5, 6, 5, 111, 1),
(6, 6, 1, 300, 1),
(7, 7, 5, 111, 1),
(8, 8, 5, 111, 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `mst_product`
--

CREATE TABLE IF NOT EXISTS `mst_product` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `gazou` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='商品のテーブル' AUTO_INCREMENT=7 ;

--
-- テーブルのデータをダンプしています `mst_product`
--

INSERT INTO `mst_product` (`code`, `name`, `price`, `gazou`) VALUES
(1, 'ハンバーガー(ロッテリア)', 300, ''),
(2, 'チキンナゲット(ロッテリア)', 400, ''),
(4, 'チキンナゲット(マクドナルド)', 300, ''),
(5, 'test', 111, 'ninjin_yama.jpg');

-- --------------------------------------------------------

--
-- テーブルの構造 `mst_staff`
--

CREATE TABLE IF NOT EXISTS `mst_staff` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- テーブルのデータをダンプしています `mst_staff`
--

INSERT INTO `mst_staff` (`code`, `name`, `password`) VALUES
(6, 'taka', 'e0ba0c0363c5c47bb4c42b39afcbe0ae'),
(3, 'うずまきナルト', 'cf9ee5bcb36b4936dd7064ee9b2f139e'),
(7, 'ryo', '86c40c09feb326e06f4040a5f781229a'),
(8, 'cat', 'd077f244def8a70e5ea758bd8352fcd8');
